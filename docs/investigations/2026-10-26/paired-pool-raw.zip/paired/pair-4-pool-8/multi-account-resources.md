# Application resource measurements (informational)

- Commit: `b7be0ee11cc34e9f25d9fcb68362ace73362f917`
- Timestamp: 2026-10-26T07:41:22.942812600Z
- Fixture version: `multiaccount-fixtures-1`
- Scope: application-process (No container infrastructure exists yet; container CPU/memory, startup-to-readiness and image size are not measured.)
- measurementKind: process (no container)
- java: Oracle Corporation 25.0.1
- os: Windows 10 10.0 amd64
- availableProcessors: 6
- maxHeapBytes: 2147483648
- postgresql: 17.11 (Debian 17.11-1.pgdg13+2)
- runner: local
- sizes: Sizes[rawItems=400, smallRecipes=200, largeRecipes=5000, bankSlots=400, typicalRequests=2, profitRepeats=1, threads=2, requestsPerThread=4, idleMillis=1000]
- investigationPoolSize: 8
- investigationAccounts: 20 distinct synthetic GUIDs; account-specific bank markers

## idle

Application idle: no requests, no tasks.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1002.832 | ms | application JVM process |
| cpu_time | 343.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 5.713 | percent of all processors | application JVM process, workload window |
| idle_heap_used | 56620600 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| idle_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 44 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 2236416 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 647168 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_full

First account refresh (POST /api/sync/account) of an account with no stored data: bank, materials, recipes, Luck.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 435.059 | ms | application JVM process |
| cpu_time | 1390.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 53.273 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 82835000 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 61.827 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 18.388 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1747 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 434.677 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 30 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 2744320 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 835584 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_incremental

Repeat account refresh after about 5% of upstream rows changed.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 234.589 | ms | application JVM process |
| cpu_time | 328.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 23.312 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 47153704 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 5.691 | ms | HTTP client round trip incl. body download, nearest-rank over 6 requests |
| http_throughput | 25.577 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 6 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1312 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 234.304 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 3307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 7415 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 55 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3096576 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 983040 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## price_refresh

Trading Post price refresh for Crafting Profit (POST /api/prices/refresh).

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 179.290 | ms | application JVM process |
| cpu_time | 234.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 21.787 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 51348008 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 7.621 | ms | HTTP client round trip incl. body download, nearest-rank over 5 requests |
| http_throughput | 27.888 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 5 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1074 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 178.847 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5400 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 5400 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 18 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3637248 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1114112 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_small

Crafting Profit (All scope, account roster) over 200 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 322.071 | ms | application JVM process |
| cpu_time | 1000 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 51.748 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 78610984 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 225.127 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 6.210 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 122084 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 100 | rows | rows in the first response |
| craftable_rows | 7 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 3311 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 7416 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 55 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3678208 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1138688 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## global_refresh

Global data refresh (POST /api/sync/global) that adds the remaining recipes and rebuilds the crafting graph.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 891.467 | ms | application JVM process |
| cpu_time | 812.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 15.190 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 82665272 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 6.590 | ms | HTTP client round trip incl. body download, nearest-rank over 18 requests |
| http_throughput | 20.191 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 18 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 3875 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 891.171 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 19200 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5602 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 75911 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 66 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_large

Crafting Profit (All scope, account roster) over 5000 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 579.788 | ms | application JVM process |
| cpu_time | 1968.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 56.594 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 383615568 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 297.984 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 3.450 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 2999679 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 2500 | rows | rows in the first response |
| craftable_rows | 12 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 45398 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 42 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_typical

Sequential typical reads: system status, bank, materials, selector options.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 200.934 | ms | application JVM process |
| cpu_time | 156.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 12.960 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 389907024 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 32.415 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 39.814 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 0 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 115788 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 185608 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 32 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## database_reads

Repository reads of Trading Post quotes and item metadata for every fixture item.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 40.647 | ms | application JVM process |
| cpu_time | 15.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 6.407 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 397247056 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| repository_read_latency_p95 | 19.989 | ms | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, nearest-rank over 2 rounds |
| repository_read_throughput | 49.204 | rounds/second | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, over the workload wall time |
| repository_read_rounds | 2 | rounds | repository call (JDBC, no HTTP), one round = TP quotes + item metadata |
| rows_returned_per_round | 10800 | rows | quotes + items returned by the last round |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 24838 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 164 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_concurrent

2 concurrent clients each issuing a mix of profit, status, bank and selector requests.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 337.070 | ms | application JVM process |
| cpu_time | 1015.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 50.218 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 374802632 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 272.190 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 23.734 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 3056338 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 21600 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 36 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_1

1 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 244.406 | ms | application JVM process |
| cpu_time | 312.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 21.310 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 312207816 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 21.478 | ms | HTTP client round trip incl. body download, nearest-rank over 5 requests |
| http_throughput | 20.458 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 5 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 28377 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 219.853 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 4 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 99018 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 81 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6160384 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1941504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_1

1 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 872.617 | ms | application JVM process |
| cpu_time | 1562.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 29.843 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 340519368 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 223.282 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 13.752 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 105 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 4584513 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 3307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 10 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 107236 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 157 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6160384 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1941504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_2

2 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 252.176 | ms | application JVM process |
| cpu_time | 468.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 30.980 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 175392448 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 27.704 | ms | HTTP client round trip incl. body download, nearest-rank over 10 requests |
| http_throughput | 39.655 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 10 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 56754 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 221.980 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 12 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 297054 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 208 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6733824 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2088960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_2

2 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1011.742 | ms | application JVM process |
| cpu_time | 2687.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 44.272 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 397690568 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 264.208 | ms | HTTP client round trip incl. body download, nearest-rank over 24 requests |
| http_throughput | 23.721 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 24 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 210 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 9169026 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 3306 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 3340 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 4 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 610546 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 514 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6733824 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2088960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_5

5 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 391.452 | ms | application JVM process |
| cpu_time | 562.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 23.949 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 289687240 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 36.788 | ms | HTTP client round trip incl. body download, nearest-rank over 30 requests |
| http_throughput | 76.638 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 30 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 10 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 142977 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 342.482 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 4 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 45 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 8650752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2949120 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_5

5 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1674.014 | ms | application JVM process |
| cpu_time | 6171.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 61.448 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 613892952 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 460.226 | ms | HTTP client round trip incl. body download, nearest-rank over 60 requests |
| http_throughput | 35.842 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 60 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 525 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 22922556 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 9918 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 6668 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 10 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 971024 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 728 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 8650752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2949120 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_10

10 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 647.826 | ms | application JVM process |
| cpu_time | 1500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 38.591 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 240075608 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 70.430 | ms | HTTP client round trip incl. body download, nearest-rank over 80 requests |
| http_throughput | 123.490 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 80 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 290286 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 570.293 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 34 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 555349 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 596 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 11960320 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4145152 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_10

10 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 2912.748 | ms | application JVM process |
| cpu_time | 10703.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 61.243 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 827087960 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 7 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 640.042 | ms | HTTP client round trip incl. body download, nearest-rank over 120 requests |
| http_throughput | 41.198 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 120 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 1050 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 45845130 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 16530 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 16676 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 20 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 2961204 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1975 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 11960320 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4145152 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_20

20 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1021.870 | ms | application JVM process |
| cpu_time | 1468.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 23.955 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 718178168 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 7 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 48.644 | ms | HTTP client round trip incl. body download, nearest-rank over 220 requests |
| http_throughput | 215.292 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 220 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 40 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 593814 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 882.191 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 14114 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2464 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 378185 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 934 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18137088 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6561792 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_20

20 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 5854.413 | ms | application JVM process |
| cpu_time | 20906.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 59.517 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 1221816664 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 7 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 1261.315 | ms | HTTP client round trip incl. body download, nearest-rank over 240 requests |
| http_throughput | 40.995 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 240 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2100 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 91690245 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 18946 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 30962 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 38 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 5749671 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 4319 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18137088 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6561792 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.
