# Application resource measurements (informational)

- Commit: `b7be0ee11cc34e9f25d9fcb68362ace73362f917`
- Timestamp: 2026-10-26T07:38:06.188881700Z
- Fixture version: `multiaccount-fixtures-1`
- Scope: application-process (No container infrastructure exists yet; container CPU/memory, startup-to-readiness and image size are not measured.)
- measurementKind: process (no container)
- java: Oracle Corporation 25.0.1
- os: Windows 10 10.0 amd64
- availableProcessors: 6
- maxHeapBytes: 2147483648
- postgresql: 17.11 (Debian 17.11-1.pgdg13+2)
- runner: local
- sizes: Sizes[rawItems=400, smallRecipes=200, largeRecipes=5000, bankSlots=400, typicalRequests=2, profitRepeats=1, threads=2, requestsPerThread=4, idleMillis=1000]
- investigationPoolSize: 0
- investigationAccounts: 20 distinct synthetic GUIDs; account-specific bank markers

## idle

Application idle: no requests, no tasks.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1004.407 | ms | application JVM process |
| cpu_time | 593.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 9.852 | percent of all processors | application JVM process, workload window |
| idle_heap_used | 50415544 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| idle_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 42 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 2236416 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 647168 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_full

First account refresh (POST /api/sync/account) of an account with no stored data: bank, materials, recipes, Luck.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 482.447 | ms | application JVM process |
| cpu_time | 1187.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 41.024 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 82921400 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 55.395 | ms | HTTP client round trip incl. body download, nearest-rank over 9 requests |
| http_throughput | 18.655 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 9 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1969 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 482.086 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 3307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 7415 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 61 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 2744320 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 835584 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_incremental

Repeat account refresh after about 5% of upstream rows changed.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 346.413 | ms | application JVM process |
| cpu_time | 375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 18.042 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 86067128 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 7.376 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 23.094 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1750 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 346.067 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 3311 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 7416 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 56 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3096576 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 983040 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## price_refresh

Trading Post price refresh for Crafting Profit (POST /api/prices/refresh).

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 179.507 | ms | application JVM process |
| cpu_time | 203.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 18.860 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 38815056 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 8.513 | ms | HTTP client round trip incl. body download, nearest-rank over 5 requests |
| http_throughput | 27.854 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 5 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1065 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 179.205 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5400 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 5400 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 18 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3637248 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1114112 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_small

Crafting Profit (All scope, account roster) over 200 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 299.768 | ms | application JVM process |
| cpu_time | 921.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 51.255 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 80758088 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 195.633 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 6.672 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 122084 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 100 | rows | rows in the first response |
| craftable_rows | 7 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 40912 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 32 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3678208 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1138688 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## global_refresh

Global data refresh (POST /api/sync/global) that adds the remaining recipes and rebuilds the crafting graph.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 939.410 | ms | application JVM process |
| cpu_time | 703.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 12.475 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 84952392 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 5.380 | ms | HTTP client round trip incl. body download, nearest-rank over 19 requests |
| http_throughput | 20.225 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 19 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 4096 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 939.111 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 19200 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5600 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 80397 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 68 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_large

Crafting Profit (All scope, account roster) over 5000 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 607.781 | ms | application JVM process |
| cpu_time | 1953.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 53.559 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 368250264 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 307.389 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 3.291 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 2999679 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 2500 | rows | rows in the first response |
| craftable_rows | 12 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 185608 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 39 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_typical

Sequential typical reads: system status, bank, materials, selector options.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 629.360 | ms | application JVM process |
| cpu_time | 1062.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 28.137 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 385027480 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 90.361 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 12.711 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 0 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 115812 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 24838 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 185 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## database_reads

Repository reads of Trading Post quotes and item metadata for every fixture item.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 85.411 | ms | application JVM process |
| cpu_time | 31.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 6.098 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 396561816 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| repository_read_latency_p95 | 44.212 | ms | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, nearest-rank over 2 rounds |
| repository_read_throughput | 23.416 | rounds/second | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, over the workload wall time |
| repository_read_rounds | 2 | rounds | repository call (JDBC, no HTTP), one round = TP quotes + item metadata |
| rows_returned_per_round | 10800 | rows | quotes + items returned by the last round |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 21600 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 27 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_concurrent

2 concurrent clients each issuing a mix of profit, status, bank and selector requests.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 532.173 | ms | application JVM process |
| cpu_time | 1203.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 37.680 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 398658968 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 329.276 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 15.033 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 3056362 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 198037 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 149 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_1

1 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 402.527 | ms | application JVM process |
| cpu_time | 484.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 20.056 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 314013920 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 72.262 | ms | HTTP client round trip incl. body download, nearest-rank over 6 requests |
| http_throughput | 14.906 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 6 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 28596 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 326.933 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 3307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 6 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 8218 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 79 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6160384 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1941504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_1

1 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1159.033 | ms | application JVM process |
| cpu_time | 1734.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 24.940 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 340228320 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 178.787 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 10.353 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 105 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 4584549 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 12 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 297054 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 235 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6160384 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1941504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_2

2 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 408.910 | ms | application JVM process |
| cpu_time | 734.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 29.932 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 194358656 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 80.772 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 29.346 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 57189 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 327.083 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 3306 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 3318 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 4 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 16442 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 135 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6742016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2088960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_2

2 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1384.645 | ms | application JVM process |
| cpu_time | 3031.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 36.486 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 398221432 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 275.543 | ms | HTTP client round trip incl. body download, nearest-rank over 24 requests |
| http_throughput | 17.333 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 24 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 210 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 9169092 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 24 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 594108 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 427 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6742016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2088960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_5

5 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 659.893 | ms | application JVM process |
| cpu_time | 1328.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 33.544 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 330403472 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 99.002 | ms | HTTP client round trip incl. body download, nearest-rank over 39 requests |
| http_throughput | 59.100 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 39 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 10 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 144948 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 534.924 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 9918 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 6642 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 10 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 41105 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 311 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 8650752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2949120 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_5

5 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 2550.631 | ms | application JVM process |
| cpu_time | 7000 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 45.740 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 564534304 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 4 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 485.305 | ms | HTTP client round trip incl. body download, nearest-rank over 60 requests |
| http_throughput | 23.524 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 60 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 525 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 22922745 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 60 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 1485270 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1012 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 8650752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2949120 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_10

10 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 956.387 | ms | application JVM process |
| cpu_time | 2046.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 35.670 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 456006688 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 10 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 10 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 147.479 | ms | HTTP client round trip incl. body download, nearest-rank over 100 requests |
| http_throughput | 104.560 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 100 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 294720 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 793.238 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 16530 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 16590 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 20 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 132210 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 600 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12017664 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4145152 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_10

10 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 3903.600 | ms | application JVM process |
| cpu_time | 12625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 53.903 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 915662816 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 10 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 815.180 | ms | HTTP client round trip incl. body download, nearest-rank over 120 requests |
| http_throughput | 30.741 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 120 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 1050 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 45845475 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 120 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 3120540 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1969 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12017664 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4145152 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_20

20 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1842.253 | ms | application JVM process |
| cpu_time | 3796.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 34.350 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 756287488 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 20 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 20 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 257.639 | ms | HTTP client round trip incl. body download, nearest-rank over 324 requests |
| http_throughput | 175.872 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 324 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 40 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 616086 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 1463.094 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 33060 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 33180 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 40 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 264420 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1184 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18661376 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6561792 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_20

20 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 8250.586 | ms | application JVM process |
| cpu_time | 25484.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 51.480 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 1453077408 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 20 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 19 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 1733.695 | ms | HTTP client round trip incl. body download, nearest-rank over 240 requests |
| http_throughput | 29.089 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 240 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2100 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 91690965 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 240 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 6240960 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 3905 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18661376 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6561792 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.
