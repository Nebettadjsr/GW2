# Application resource measurements (informational)

- Commit: `b7be0ee11cc34e9f25d9fcb68362ace73362f917`
- Timestamp: 2026-10-26T07:40:23.349892700Z
- Fixture version: `multiaccount-fixtures-1`
- Scope: application-process (No container infrastructure exists yet; container CPU/memory, startup-to-readiness and image size are not measured.)
- measurementKind: process (no container)
- java: Oracle Corporation 25.0.1
- os: Windows 10 10.0 amd64
- availableProcessors: 6
- maxHeapBytes: 2147483648
- postgresql: 17.11 (Debian 17.11-1.pgdg13+2)
- runner: local
- sizes: Sizes[rawItems=400, smallRecipes=200, largeRecipes=5000, bankSlots=400, typicalRequests=2, profitRepeats=1, threads=2, requestsPerThread=4, idleMillis=1000]
- investigationPoolSize: 8
- investigationAccounts: 20 distinct synthetic GUIDs; account-specific bank markers

## idle

Application idle: no requests, no tasks.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1002.448 | ms | application JVM process |
| cpu_time | 765.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 12.729 | percent of all processors | application JVM process, workload window |
| idle_heap_used | 60469336 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| idle_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 45 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 2236416 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 647168 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_full

First account refresh (POST /api/sync/account) of an account with no stored data: bank, materials, recipes, Luck.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 478.215 | ms | application JVM process |
| cpu_time | 1125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 39.208 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 80392280 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 49.423 | ms | HTTP client round trip incl. body download, nearest-rank over 9 requests |
| http_throughput | 18.820 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 9 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1969 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 477.901 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 31 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 2744320 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 835584 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_incremental

Repeat account refresh after about 5% of upstream rows changed.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 297.208 | ms | application JVM process |
| cpu_time | 250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 14.019 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 51867064 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 12.231 | ms | HTTP client round trip incl. body download, nearest-rank over 7 requests |
| http_throughput | 23.553 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 7 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1531 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 296.791 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 3307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 7415 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 57 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3096576 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 983040 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## price_refresh

Trading Post price refresh for Crafting Profit (POST /api/prices/refresh).

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 178.799 | ms | application JVM process |
| cpu_time | 203.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 18.934 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 56061368 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 7.699 | ms | HTTP client round trip incl. body download, nearest-rank over 5 requests |
| http_throughput | 27.964 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 5 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1089 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 178.446 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5400 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 5400 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 18 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3637248 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1114112 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_small

Crafting Profit (All scope, account roster) over 200 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 269.629 | ms | application JVM process |
| cpu_time | 781.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 48.292 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 83324344 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 183.927 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 7.418 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 122078 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 100 | rows | rows in the first response |
| craftable_rows | 7 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 3311 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 7416 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 54 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 3678208 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1138688 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## global_refresh

Global data refresh (POST /api/sync/global) that adds the remaining recipes and rebuilds the crafting graph.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1171.935 | ms | application JVM process |
| cpu_time | 1015.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 14.444 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 84152184 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 33.608 | ms | HTTP client round trip incl. body download, nearest-rank over 19 requests |
| http_throughput | 16.212 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 19 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 4096 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 1171.618 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 19200 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5602 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 75911 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 66 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_large

Crafting Profit (All scope, account roster) over 5000 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 983.304 | ms | application JVM process |
| cpu_time | 2406.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 40.785 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 286470184 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 466.495 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 2.034 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 2999679 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 2500 | rows | rows in the first response |
| craftable_rows | 12 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 45398 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 48 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_typical

Sequential typical reads: system status, bank, materials, selector options.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 227.247 | ms | application JVM process |
| cpu_time | 234.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 17.189 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 293810216 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 39.740 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 35.204 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 0 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 115806 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 185608 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 33 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## database_reads

Repository reads of Trading Post quotes and item metadata for every fixture item.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 43.136 | ms | application JVM process |
| cpu_time | 31.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 12.074 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 305344552 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| repository_read_latency_p95 | 21.976 | ms | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, nearest-rank over 2 rounds |
| repository_read_throughput | 46.365 | rounds/second | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, over the workload wall time |
| repository_read_rounds | 2 | rounds | repository call (JDBC, no HTTP), one round = TP quotes + item metadata |
| rows_returned_per_round | 10800 | rows | quotes + items returned by the last round |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 24838 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 164 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_concurrent

2 concurrent clients each issuing a mix of profit, status, bank and selector requests.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 356.974 | ms | application JVM process |
| cpu_time | 1046.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 48.877 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 378392616 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 284.913 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 22.411 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 3056356 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 21600 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 36 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5718016 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1712128 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_1

1 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 363.410 | ms | application JVM process |
| cpu_time | 453.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 20.781 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 224604200 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 26.996 | ms | HTTP client round trip incl. body download, nearest-rank over 6 requests |
| http_throughput | 16.510 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 6 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 28596 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 333.153 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 198039 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 151 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6160384 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1941504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_1

1 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 881.070 | ms | application JVM process |
| cpu_time | 1906.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 36.059 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 258559400 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 248.472 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 13.620 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 105 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 4584540 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 3307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 6 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 8218 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 93 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6160384 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1941504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_2

2 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 262.828 | ms | application JVM process |
| cpu_time | 500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 31.706 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 83853896 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 28.400 | ms | HTTP client round trip incl. body download, nearest-rank over 10 requests |
| http_throughput | 38.048 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 10 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 56754 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 230.946 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 12 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 297054 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 208 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6733824 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2088960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_2

2 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1041.428 | ms | application JVM process |
| cpu_time | 1984.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 31.757 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 389501560 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 290.874 | ms | HTTP client round trip incl. body download, nearest-rank over 24 requests |
| http_throughput | 23.045 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 24 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 210 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 9169080 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 3306 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 3338 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 4 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 599738 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 480 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6733824 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2088960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_5

5 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 470.917 | ms | application JVM process |
| cpu_time | 828.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 29.309 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 184073000 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 3 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 33.504 | ms | HTTP client round trip incl. body download, nearest-rank over 31 requests |
| http_throughput | 65.829 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 31 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 10 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 143169 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 359.268 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 4 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 10812 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 84 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 8650752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2965504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_5

5 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1741.550 | ms | application JVM process |
| cpu_time | 6593.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 63.102 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 657457152 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 4 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 462.472 | ms | HTTP client round trip incl. body download, nearest-rank over 60 requests |
| http_throughput | 34.452 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 60 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 525 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 22922694 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 9918 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 6669 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 10 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 1006424 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 733 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 8650752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2965504 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_10

10 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 734.360 | ms | application JVM process |
| cpu_time | 1296.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 29.433 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 196608000 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 7 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 34.010 | ms | HTTP client round trip incl. body download, nearest-rank over 88 requests |
| http_throughput | 119.832 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 88 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 292092 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 664.406 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 33 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 519951 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 598 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 11927552 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4161536 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_10

10 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 2949.585 | ms | application JVM process |
| cpu_time | 11109.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 62.774 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 853540864 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 656.882 | ms | HTTP client round trip incl. body download, nearest-rank over 120 requests |
| http_throughput | 40.684 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 120 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 1050 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 45845400 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 16530 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 16674 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 20 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 2949985 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1969 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12025856 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4161536 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_20

20 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1151.378 | ms | application JVM process |
| cpu_time | 1687.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 24.427 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 312809984 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 7 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 62.383 | ms | HTTP client round trip incl. body download, nearest-rank over 220 requests |
| http_throughput | 191.075 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 220 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 40 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 593487 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 888.617 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 23545 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 24469 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 22 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 599799 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1528 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 16744448 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6561792 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_20

20 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 5601.335 | ms | application JVM process |
| cpu_time | 19687.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 58.580 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 1327299536 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 6 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 1076.057 | ms | HTTP client round trip incl. body download, nearest-rank over 240 requests |
| http_throughput | 42.847 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 240 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2100 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 91690779 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 9515 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8926 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 18 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 4822768 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 3204 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 16744448 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6561792 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.
