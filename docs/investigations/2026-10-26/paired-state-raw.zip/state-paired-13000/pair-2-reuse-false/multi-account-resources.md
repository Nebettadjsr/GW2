# Application resource measurements (informational)

- Commit: `bdec991a56fd2cabd38b8db16a83b7c61bfb311d`
- Timestamp: 2026-10-26T08:21:49.561400700Z
- Fixture version: `multiaccount-fixtures-1`
- Scope: application-process (No container infrastructure exists yet; container CPU/memory, startup-to-readiness and image size are not measured.)
- measurementKind: process (no container)
- java: Oracle Corporation 25.0.1
- os: Windows 10 10.0 amd64
- availableProcessors: 6
- maxHeapBytes: 2147483648
- postgresql: 17.11 (Debian 17.11-1.pgdg13+2)
- runner: local
- sizes: Sizes[rawItems=400, smallRecipes=200, largeRecipes=13000, bankSlots=400, typicalRequests=2, profitRepeats=1, threads=2, requestsPerThread=4, idleMillis=1000]
- investigationPoolSize: 8
- investigationReuseState: false
- investigationAccounts: 20 distinct synthetic GUIDs; account-specific bank markers

## idle

Application idle: no requests, no tasks.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1002.169 | ms | application JVM process |
| cpu_time | 359.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 5.977 | percent of all processors | application JVM process, workload window |
| idle_heap_used | 54412160 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| idle_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 44 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 4620288 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1187840 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_full

First account refresh (POST /api/sync/account) of an account with no stored data: bank, materials, recipes, Luck.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 592.568 | ms | application JVM process |
| cpu_time | 1328.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 37.355 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 85869440 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 52.469 | ms | HTTP client round trip incl. body download, nearest-rank over 11 requests |
| http_throughput | 18.563 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 11 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 2407 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 592.241 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 36 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5521408 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1531904 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_incremental

Repeat account refresh after about 5% of upstream rows changed.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 288.022 | ms | application JVM process |
| cpu_time | 343.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 19.891 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 45707520 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 6.547 | ms | HTTP client round trip incl. body download, nearest-rank over 7 requests |
| http_throughput | 24.304 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 7 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1531 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 287.736 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 7307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 15415 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 57 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6291456 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1851392 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## price_refresh

Trading Post price refresh for Crafting Profit (POST /api/prices/refresh).

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 351.795 | ms | application JVM process |
| cpu_time | 265.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 12.584 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 53047552 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 13.983 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 22.741 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1770 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 351.244 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 13400 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 13400 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 25 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 7610368 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2146304 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_small

Crafting Profit (All scope, account roster) over 200 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 257.249 | ms | application JVM process |
| cpu_time | 687.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 44.542 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 83456256 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 181.269 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 7.775 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 122081 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 100 | rows | rows in the first response |
| craftable_rows | 7 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 7311 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 15416 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 54 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 7651328 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2170880 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## global_refresh

Global data refresh (POST /api/sync/global) that adds the remaining recipes and rebuilds the crafting graph.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1918.653 | ms | application JVM process |
| cpu_time | 953.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 8.279 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 86437232 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 4.759 | ms | HTTP client round trip incl. body download, nearest-rank over 37 requests |
| http_throughput | 19.284 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 37 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 8020 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 1918.257 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 51200 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 13602 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 179911 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 105 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12910592 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_large

Crafting Profit (All scope, account roster) over 13000 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1099.923 | ms | application JVM process |
| cpu_time | 3765.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 57.059 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 399270824 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 576.578 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 1.818 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 7795402 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 6500 | rows | rows in the first response |
| craftable_rows | 13 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 591006 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 117 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12976128 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_typical

Sequential typical reads: system status, bank, materials, selector options.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 183.771 | ms | application JVM process |
| cpu_time | 187.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 17.005 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 401966024 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 31.669 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 43.533 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 0 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 115814 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 20 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12976128 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## database_reads

Repository reads of Trading Post quotes and item metadata for every fixture item.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 70.067 | ms | application JVM process |
| cpu_time | 125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 29.733 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 425034696 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| repository_read_latency_p95 | 35.586 | ms | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, nearest-rank over 2 rounds |
| repository_read_throughput | 28.544 | rounds/second | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, over the workload wall time |
| repository_read_rounds | 2 | rounds | repository call (JDBC, no HTTP), one round = TP quotes + item metadata |
| rows_returned_per_round | 26800 | rows | quotes + items returned by the last round |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 30842 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 162 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12976128 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_concurrent

2 concurrent clients each issuing a mix of profit, status, bank and selector requests.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 600.609 | ms | application JVM process |
| cpu_time | 1718.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 47.695 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 453471984 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 539.283 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 13.320 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 7852084 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 53600 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 44 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12976128 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_1

1 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 356.755 | ms | application JVM process |
| cpu_time | 359.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 16.789 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 152043520 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 28.866 | ms | HTTP client round trip incl. body download, nearest-rank over 6 requests |
| http_throughput | 16.818 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 6 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 28572 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 324.549 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 502041 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 151 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 13492224 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4136960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_1

1 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1288.963 | ms | application JVM process |
| cpu_time | 2703.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 34.952 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 596102640 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 356.152 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 9.310 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 105 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 11778129 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 7307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 9 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 204283 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 152 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 13492224 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4136960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_2

2 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 352.998 | ms | application JVM process |
| cpu_time | 265.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 12.541 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 186646528 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 23.627 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 33.995 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 57192 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 327.384 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 9 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 378539 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 168 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 14696448 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4415488 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_2

2 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1807.363 | ms | application JVM process |
| cpu_time | 5078.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 46.828 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 772118528 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 572.025 | ms | HTTP client round trip incl. body download, nearest-rank over 24 requests |
| http_throughput | 13.279 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 24 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 210 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 23556261 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 7306 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 7328 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 4 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 759486 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 314 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 14696448 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4415488 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_5

5 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 482.711 | ms | application JVM process |
| cpu_time | 656.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 22.658 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 389388288 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 33.225 | ms | HTTP client round trip incl. body download, nearest-rank over 35 requests |
| http_throughput | 72.507 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 35 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 10 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 144030 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 444.537 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 14 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 406164 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 271 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18841600 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6307840 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_5

5 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 3416.929 | ms | application JVM process |
| cpu_time | 13234.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 64.553 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 1027570816 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 1026.325 | ms | HTTP client round trip incl. body download, nearest-rank over 60 requests |
| http_throughput | 17.560 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 60 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 525 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 58890657 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 21918 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 14689 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 10 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 2844661 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1088 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18841600 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6307840 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_10

10 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 931.101 | ms | application JVM process |
| cpu_time | 1500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 26.850 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 746586112 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 29.219 | ms | HTTP client round trip incl. body download, nearest-rank over 105 requests |
| http_throughput | 112.770 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 105 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 295755 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 830.602 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 13 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 69864 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 287 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 25985024 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 9003008 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_10

10 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 7109.749 | ms | application JVM process |
| cpu_time | 28281.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 66.297 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 1525678080 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 1702.981 | ms | HTTP client round trip incl. body download, nearest-rank over 120 requests |
| http_throughput | 16.878 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 120 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 1050 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 117781308 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 36530 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 36692 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 20 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 5568721 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 2301 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 25985024 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 9003008 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_20

20 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1718.345 | ms | application JVM process |
| cpu_time | 2437.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 23.642 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 411370992 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 46.720 | ms | HTTP client round trip incl. body download, nearest-rank over 323 requests |
| http_throughput | 187.972 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 323 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 40 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 616248 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 1414.269 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 46625 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 66607 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 501099 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 810 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 40116224 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 14336000 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_20

20 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 15688.665 | ms | application JVM process |
| cpu_time | 64062.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 68.056 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 1251475456 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 3340.819 | ms | HTTP client round trip incl. body download, nearest-rank over 240 requests |
| http_throughput | 15.298 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 240 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2100 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 235562622 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 26435 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 6804 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 40 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 11128562 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 4330 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 40116224 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 14336000 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.
