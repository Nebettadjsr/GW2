# Application resource measurements (informational)

- Commit: `bdec991a56fd2cabd38b8db16a83b7c61bfb311d`
- Timestamp: 2026-10-26T08:29:40.083275900Z
- Fixture version: `multiaccount-fixtures-1`
- Scope: application-process (No container infrastructure exists yet; container CPU/memory, startup-to-readiness and image size are not measured.)
- measurementKind: process (no container)
- java: Oracle Corporation 25.0.1
- os: Windows 10 10.0 amd64
- availableProcessors: 6
- maxHeapBytes: 2147483648
- postgresql: 17.11 (Debian 17.11-1.pgdg13+2)
- runner: local
- sizes: Sizes[rawItems=400, smallRecipes=200, largeRecipes=13000, bankSlots=400, typicalRequests=2, profitRepeats=1, threads=2, requestsPerThread=4, idleMillis=1000]
- investigationPoolSize: 8
- investigationReuseState: true
- investigationAccounts: 20 distinct synthetic GUIDs; account-specific bank markers

## idle

Application idle: no requests, no tasks.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1001.775 | ms | application JVM process |
| cpu_time | 515.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 8.579 | percent of all processors | application JVM process, workload window |
| idle_heap_used | 62345664 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| idle_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 0 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 44 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 4620288 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1187840 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_full

First account refresh (POST /api/sync/account) of an account with no stored data: bank, materials, recipes, Luck.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 588.249 | ms | application JVM process |
| cpu_time | 1234.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 34.973 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 83317184 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 50.708 | ms | HTTP client round trip incl. body download, nearest-rank over 11 requests |
| http_throughput | 18.700 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 11 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 2407 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 587.939 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 0 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 36 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 5521408 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1531904 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## account_sync_incremental

Repeat account refresh after about 5% of upstream rows changed.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 285.979 | ms | application JVM process |
| cpu_time | 250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 14.570 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 56789736 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 5.156 | ms | HTTP client round trip incl. body download, nearest-rank over 7 requests |
| http_throughput | 24.477 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 7 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1528 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 285.547 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 7307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 15415 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 57 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 6291456 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 1851392 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## price_refresh

Trading Post price refresh for Crafting Profit (POST /api/prices/refresh).

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 288.391 | ms | application JVM process |
| cpu_time | 218.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 12.642 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 64129768 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 7.942 | ms | HTTP client round trip incl. body download, nearest-rank over 7 requests |
| http_throughput | 24.273 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 7 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 1543 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 288.094 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 13400 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 13400 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 22 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 7610368 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2146304 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_small

Crafting Profit (All scope, account roster) over 200 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 253.791 | ms | application JVM process |
| cpu_time | 609.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 40.018 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 83004136 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 180.591 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 7.880 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 122081 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 100 | rows | rows in the first response |
| craftable_rows | 7 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 7311 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 15416 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 54 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 7651328 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 2170880 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## global_refresh

Global data refresh (POST /api/sync/global) that adds the remaining recipes and rebuilds the crafting graph.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 2034.014 | ms | application JVM process |
| cpu_time | 1328.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 10.883 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 80608048 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 5.323 | ms | HTTP client round trip incl. body download, nearest-rank over 39 requests |
| http_throughput | 19.174 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 39 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 8456 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 2033.688 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 51200 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 13602 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 179911 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 109 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12910592 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## profit_large

Crafting Profit (All scope, account roster) over 13000 recipes; first call, then repeats with changed settings.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 987.060 | ms | application JVM process |
| cpu_time | 3125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 52.766 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 178405384 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 491.430 | ms | HTTP client round trip incl. body download, nearest-rank over 2 requests |
| http_throughput | 2.026 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 2 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 70 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 7795399 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| result_rows | 6500 | rows | rows in the first response |
| craftable_rows | 13 | rows | rows of the first response whose calculation crafted at least one item (craftableCount > 0) |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 117398 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 58 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12910592 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_typical

Sequential typical reads: system status, bank, materials, selector options.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 253.109 | ms | application JVM process |
| cpu_time | 359.375 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 23.664 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 138760584 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 53.477 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 31.607 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 0 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 115808 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 2 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 473608 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 34 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12910592 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## database_reads

Repository reads of Trading Post quotes and item metadata for every fixture item.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 72.132 | ms | application JVM process |
| cpu_time | 78.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 18.052 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 161829256 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| repository_read_latency_p95 | 36.050 | ms | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, nearest-rank over 2 rounds |
| repository_read_throughput | 27.727 | rounds/second | repository call (JDBC, no HTTP), one round = TP quotes + item metadata, over the workload wall time |
| repository_read_rounds | 2 | rounds | repository call (JDBC, no HTTP), one round = TP quotes + item metadata |
| rows_returned_per_round | 26800 | rows | quotes + items returned by the last round |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 8 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 56838 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 165 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12910592 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## http_concurrent

2 concurrent clients each issuing a mix of profit, status, bank and selector requests.

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 545.835 | ms | application JVM process |
| cpu_time | 1562.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 47.710 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 434426504 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 472.406 | ms | HTTP client round trip incl. body download, nearest-rank over 8 requests |
| http_throughput | 14.656 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 8 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 7852078 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 53600 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 43 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 12910592 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 3620864 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_1

1 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 347.160 | ms | application JVM process |
| cpu_time | 656.250 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 31.506 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 445960840 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 20.010 | ms | HTTP client round trip incl. body download, nearest-rank over 6 requests |
| http_throughput | 17.283 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 6 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 28596 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 323.905 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 5 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 251023 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 105 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 13877248 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4136960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_1

1 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1190.244 | ms | application JVM process |
| cpu_time | 1640.625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 22.973 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 462738056 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 1 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 318.783 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 10.082 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 105 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 11778123 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 7307 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 12 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 754245 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 226 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 13942784 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4136960 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_2

2 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 360.033 | ms | application JVM process |
| cpu_time | 171.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 7.956 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 436518928 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 30.305 | ms | HTTP client round trip incl. body download, nearest-rank over 12 requests |
| http_throughput | 33.330 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 12 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 4 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 57192 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 329.323 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 9 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 266441 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 183 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 14696448 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4440064 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_2

2 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1527.407 | ms | application JVM process |
| cpu_time | 3062.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 33.417 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 486613384 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 2 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 412.800 | ms | HTTP client round trip incl. body download, nearest-rank over 24 requests |
| http_throughput | 15.713 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 24 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 210 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 23556246 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 7306 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 7330 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 4 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 1085377 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 345 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 14696448 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 4440064 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_5

5 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 574.124 | ms | application JVM process |
| cpu_time | 625 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 18.144 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 139534728 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 28.785 | ms | HTTP client round trip incl. body download, nearest-rank over 36 requests |
| http_throughput | 62.704 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 36 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 10 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 144294 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 464.532 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 12 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 496707 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 238 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18890752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6373376 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_5

5 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 2782.650 | ms | application JVM process |
| cpu_time | 9468.750 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 56.713 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 738403296 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 5 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 769.367 | ms | HTTP client round trip incl. body download, nearest-rank over 60 requests |
| http_throughput | 21.562 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 60 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 525 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 58890609 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 21918 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 14687 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 10 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 3638265 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 1041 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 18890752 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 6373376 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_10

10 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1030.820 | ms | application JVM process |
| cpu_time | 1828.125 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 29.558 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 423220272 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 28.009 | ms | HTTP client round trip incl. body download, nearest-rank over 108 requests |
| http_throughput | 104.771 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 108 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 20 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 296469 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 874.261 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 7709 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 14242 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 6 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 141220 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 501 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 26025984 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 9019392 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_10

10 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 5605.831 | ms | application JVM process |
| cpu_time | 19171.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 57.000 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 735051776 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 1304.618 | ms | HTTP client round trip incl. body download, nearest-rank over 120 requests |
| http_throughput | 21.406 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 120 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 1050 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 117781218 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 28821 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 22461 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 14 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 6114534 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 2041 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 26025984 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 9019392 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_onboarding_20

20 distinct accounts concurrently synchronize

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 1887.544 | ms | application JVM process |
| cpu_time | 2296.875 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 20.281 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 293076992 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 24.904 | ms | HTTP client round trip incl. body download, nearest-rank over 371 requests |
| http_throughput | 196.552 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 371 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 40 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 626535 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| background_job_duration | 1678.392 | ms | HTTP accept to terminal task state (mean over runs) |
| background_job_cpu_time | unavailable: the task runs on shared pool threads; only the whole-process CPU of the workload window is attributable | ms | task |
| background_job_memory | unavailable: JVM heap is shared; only the workload-window peak above is observable | bytes | task |
| scheduled_global_refresh_interval | 21600000 | ms | configured value (gw2.global-refresh.interval-ms), not an observed frequency; account and price refreshes are demand-driven |
| db_rows_inserted | 47028 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 47101 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 0 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 1011487 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 884 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 40239104 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 14311424 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.

## accounts_mixed_20

20 isolated accounts: changed-budget Profit plus bank/status/selectors

| KPI | Value | Unit | Boundary |
|---|---|---|---|
| wall_time | 11300.457 | ms | application JVM process |
| cpu_time | 39312.500 | ms | application JVM process, user+system, workload window |
| cpu_utilization | 57.981 | percent of all processors | application JVM process, workload window |
| peak_heap_used | 1193279488 | bytes | application JVM process, sampled every 20 ms (lower bound of the true peak) |
| peak_rss | unavailable: /proc/self/status is not available on this platform | bytes | application JVM process |
| db_connections_open_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; counts every state including idle, sampled every 25 ms (lower bound) |
| db_connections_active_peak | 8 | connections | database-wide pg_stat_activity (client backends of the test database, not only this schema); one persistent observer session is excluded, as are the statistics probe sessions; other database clients, fixture writers and the observer's own small query load are not excluded; only state 'active', point samples so short statements are mostly missed, sampled every 25 ms (lower bound) |
| http_latency_p95 | 2460.143 | ms | HTTP client round trip incl. body download, nearest-rank over 240 requests |
| http_throughput | 21.238 | requests/second | all recorded requests (including task-status polls) over wall time |
| http_requests | 240 | requests | HTTP client round trip incl. body download |
| http_errors | 0 | requests | non-2xx responses |
| network_ingress | 2100 | bytes | HTTP request bodies received by the application; headers and TCP overhead excluded |
| network_egress | 235562436 | bytes | HTTP response bodies sent by the application; headers and TCP overhead excluded |
| db_rows_inserted | 26032 | rows | test schema (pg_stat_all_tables) |
| db_rows_updated | 26310 | rows | test schema (pg_stat_all_tables) |
| db_rows_deleted | 40 | rows | test schema (pg_stat_all_tables) |
| db_rows_read | 12395761 | rows | test schema (pg_stat_all_tables), sequential scan rows + index fetches |
| db_transactions_committed | 4234 | transactions | whole test database (pg_stat_database) |
| db_storage_total | 40239104 | bytes | test schema (pg_stat_all_tables), tables + indexes + TOAST at workload end |
| db_storage_indexes | 14311424 | bytes | test schema (pg_stat_all_tables), at workload end |
| db_network_bytes | unavailable: no per-process network counters are available without OS tooling; HTTP body bytes are reported instead | bytes | JDBC wire |

- Limit: Process figures cover the whole JVM, which also hosts the in-process load-generating client and fixture writers.
- Limit: Fixture data is synthetic (perf-fixtures-2); sizes are not a claim about real GW2 data volumes.
